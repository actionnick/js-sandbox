var React = require('react');

alert("Change this to see live reloading in progress");